# Cyber Security CLI Quest — Online Lab

Lab praktikum berbasis browser dengan konsep Bandit Level 0–17. Dibuat untuk berjalan di GitHub Codespaces sehingga peserta tidak perlu memasang VM Linux di komputer.

## Cara menerbitkan lab online
1. Buat repository GitHub baru bernama `cyber-security-cli-quest`.
2. Upload seluruh isi folder paket ini ke repository (termasuk folder `.devcontainer`).
3. Buka repository di GitHub, pilih **Code → Codespaces → Create codespace on main**.
4. Tunggu sampai environment selesai dibuat. Terminal akan tersedia di browser.
5. Di terminal Codespaces jalankan:
   ```bash
   bash start-lab.sh
   ```
6. Mulai tantangan:
   ```bash
   cd ~/cyber-lab/level00
   cat README.txt
   ```

## Mekanisme level
- Level 00 terbuka pada awalnya.
- Peserta menemukan token dan mengirimnya dengan `cyber-submit 00 'TOKEN{...}'`.
- Token benar membuka level selanjutnya.
- Kunci jawaban instruktur berada di `instructor/ANSWER_KEY.txt`. Jangan bagikan file ini kepada peserta.

## Penting tentang mode ujian
Paket ini menyiapkan lab yang dapat dijalankan di Codespaces, bukan otomatis menerbitkan situs publik. Untuk ujian, buat satu Codespace per peserta atau gunakan lingkungan yang dikelola guru. Codespaces memiliki kuota/limit berdasarkan akun dan kebijakan GitHub; akses online tetap memerlukan akun GitHub.

## Batasan keamanan
Permission Linux mengunci direktori dari pengguna biasa, tetapi administrator/root atau peserta yang diberi akses terminal dengan hak tinggi masih bisa mengakses semua file. Untuk ujian berisiko tinggi, gunakan satu container/VM terisolasi per peserta dan jangan menaruh kunci jawaban di filesystem peserta.
