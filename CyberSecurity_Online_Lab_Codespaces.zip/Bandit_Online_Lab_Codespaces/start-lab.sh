#!/usr/bin/env bash
set -euo pipefail
LAB="$HOME/cyber-lab"
mkdir -p "$LAB"
python3 - "$LAB" <<'PY'
import os, sys, gzip, bz2, lzma, hashlib
lab=sys.argv[1]
tasks=[
"Mulai dengan membaca start-here.txt.",
"Temukan file tersembunyi dengan ls -la.",
"Baca file yang namanya mengandung spasi tanpa mengganti namanya.",
"Temukan clue.txt pada subdirektori.",
"Cari kata kunci KUNCI-TERSEMBUNYI.",
"Ambil baris yang diawali TARGET: dan periksa hasilnya.",
"Periksa permission file dengan ls -l, lalu baca locked.txt.",
"Urutkan events.log dan temukan baris yang muncul sekali.",
"Dekode encoded.txt. Base64 adalah encoding, bukan enkripsi.",
"Pulihkan teks ROT13 pada message.txt.",
"Identifikasi bytes.bin dan temukan teks yang tersimpan.",
"Ekstrak clue.gz.",
"Ekstrak bundle.bz2.",
"Ekstrak payload.xz.",
"Kenali dan ekstrak arsip berlapis pada layers.bin.",
"Hitung SHA-256 candidate.txt dan cocokkan dengan checksums.txt.",
"Bandingkan old.txt dan new.txt dengan diff.",
"Analisis auth.log untuk event SUCCESS dan hostname terkait."
]
files=[
{"start-here.txt":"Petunjuk awal berhasil ditemukan.\nTOKEN{mulai_dari_file}\n"},
{".secret-note":"TOKEN{file_tersembunyi}\n","README-hint.txt":"Coba tampilkan file tersembunyi.\n"},
{"read me please.txt":"TOKEN{spasi_bukan_masalah}\n"},
{"notes/clue.txt":"TOKEN{temukan_lokasi}\n"},
{"alpha.txt":"Catatan biasa.\n","beta.txt":"KUNCI-TERSEMBUNYI: TOKEN{grep_menemukan}\n","gamma.txt":"Tidak ada token di sini.\n"},
{"records.txt":"INFO: mulai\nTARGET:TOKEN{filter_dan_urut}\nINFO: selesai\nTARGOT:abaikan-baris-ini\n"},
{"locked.txt":"TOKEN{permission_dipahami}\n","hint.txt":"Gunakan ls -l untuk memeriksa permission.\n"},
{"events.log":"LOGIN\nPING\nPING\nALERT-UNIK:TOKEN{unik_setelah_sort}\nLOGIN\n"},
{"encoded.txt":"VE9LRU57YmFzZTY0X2J1a2FuX2Vua3JpcHNpfQ==\n"},
{"message.txt":"GBXRA{ebgnfv_grxf}\n"},
{"bytes.bin":bytes([84,79,75,69,78,123,98,121,116,101,95,106,97,100,105,95,116,101,107,115,125,10])},
{"clue.gz":gzip.compress(b"TOKEN{gzip_terbuka}\n")},
{"bundle.bz2":bz2.compress(b"TOKEN{bzip2_terbuka}\n")},
{"payload.xz":lzma.compress(b"TOKEN{xz_terbuka}\n")},
{"layers.bin":None},
{"candidate.txt":"file-candidate-01\nTOKEN{checksum_cocok}\n","checksums.txt":None},
{"old.txt":"status=ready\nhost=lab-node\n","new.txt":"status=ready\nhost=lab-node\nTOKEN{diff_menemukan_perubahan}\n"},
{"auth.log":"2025-07-15T10:20:00Z host=WS-LAB-07 event=FAIL user=student\n2025-07-15T10:22:00Z host=WS-LAB-07 event=SUCCESS user=analyst\n2025-07-15T10:23:00Z host=WS-LAB-07 event=SESSION user=analyst\n","final-token.txt":"Hostname hasil investigasi: WS-LAB-07\nTOKEN{investigasi_selesai}\n"}
]
for i, fs in enumerate(files):
    d=os.path.join(lab,f"level{i:02d}")
    os.makedirs(d,exist_ok=True)
    with open(os.path.join(d,"README.txt"),"w") as f:
        f.write(f"LEVEL {i:02d} — PETUNJUK\n\n{tasks[i]}\n\nSetelah menemukan token, jalankan:\ncyber-submit {i:02d} 'TOKEN_YANG_DITEMUKAN'\n")
    for name, content in fs.items():
        p=os.path.join(d,name); os.makedirs(os.path.dirname(p),exist_ok=True)
        if content is not None:
            with open(p,"wb" if isinstance(content,bytes) else "w") as f: f.write(content)
# archive chain
inner=lzma.compress(b"TOKEN{rantai_arsip}\n")
open(os.path.join(lab,"level14/layers.bin"),"wb").write(gzip.compress(bz2.compress(inner)))
# checksum
candidate=os.path.join(lab,"level15/candidate.txt")
digest=hashlib.sha256(open(candidate,"rb").read()).hexdigest()
open(os.path.join(lab,"level15/checksums.txt"),"w").write(digest+"  candidate.txt\n")
PY

cat > "$HOME/.local/bin/cyber-submit" <<'SUBMIT'
#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 2 ]]; then echo "Usage: cyber-submit LEVEL 'TOKEN{...}'"; exit 2; fi
lvl="$1"; token="$2"
if [[ ! "$lvl" =~ ^([0-9]|1[0-7])$ ]]; then echo "Level harus 00–17."; exit 2; fi
n=$((10#$lvl))
expected=(
'TOKEN{mulai_dari_file}' 'TOKEN{file_tersembunyi}' 'TOKEN{spasi_bukan_masalah}' 'TOKEN{temukan_lokasi}'
'TOKEN{grep_menemukan}' 'TOKEN{filter_dan_urut}' 'TOKEN{permission_dipahami}' 'TOKEN{unik_setelah_sort}'
'TOKEN{base64_bukan_enkripsi}' 'TOKEN{rotasi_teks}' 'TOKEN{byte_jadi_teks}' 'TOKEN{gzip_terbuka}'
'TOKEN{bzip2_terbuka}' 'TOKEN{xz_terbuka}' 'TOKEN{rantai_arsip}' 'TOKEN{checksum_cocok}'
'TOKEN{diff_menemukan_perubahan}' 'TOKEN{investigasi_selesai}'
)
if [[ "$token" != "${expected[$n]}" ]]; then echo "Token salah. Periksa bukti dan perintahmu."; exit 1; fi
next=$((n+1))
if [[ "$n" -lt 17 ]]; then
  chmod -R u+rwX "$HOME/cyber-lab/level$(printf '%02d' "$next")"
  echo "Benar! Level $(printf '%02d' "$next") dibuka."
else
  echo "Selamat, seluruh level selesai."
fi
SUBMIT
chmod +x "$HOME/.local/bin/cyber-submit"
echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
# Gate all directories except level00 for ordinary access
for i in $(seq -w 1 17); do chmod -R go-rwx "$LAB/level$i"; done
chmod -R u+rwX "$LAB/level00"
echo "Lab siap. Jalankan: cd ~/cyber-lab/level00 && cat README.txt"
